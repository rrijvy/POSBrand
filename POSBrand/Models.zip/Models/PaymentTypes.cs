﻿namespace POSBrand.Models
{
    public enum PaymentTypes
    {
        Cash,
        CreditCard,
        BKash,
        Rocket
    };
}
